package com.library.service;

public class BookService {
    // Service methods for managing books
    public void displayServiceInfo() {
        System.out.println("BookService is up and running!");
    }
}
