package com.library.repository;

public class BookRepository {
    // Repository methods for managing book data
    public void displayRepositoryInfo() {
        System.out.println("BookRepository is up and running!");
    }
}
