package com.library.repository;

public class BookRepository {
    public void performRepositoryAction() {
        System.out.println("Book Repository action performed.");
    }
}
