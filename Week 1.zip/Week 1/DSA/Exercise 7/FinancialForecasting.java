
public class FinancialForecasting {

    public static double calculateFutureValue(double initialValue, double growthRate, int periods) {
        if (periods == 0) {
            return initialValue;
        }
        
        double previousValue = calculateFutureValue(initialValue, growthRate, periods - 1);
    
        return previousValue * (1 + growthRate);
    }

    public static void main(String[] args) {
        double initialValue = 1000.0; // Initial investment
        double growthRate = 0.05; // Growth rate
        int periods = 10; // Number of periods 

        double futureValue = calculateFutureValue(initialValue, growthRate, periods);

        System.out.println("Future Value: " + futureValue);
    }
}

//Optimization:To avoid excessive computation and improve efficiency, we can use memoization. Memoization stores the results of expensive function calls and reuses them when the same inputs occur again.