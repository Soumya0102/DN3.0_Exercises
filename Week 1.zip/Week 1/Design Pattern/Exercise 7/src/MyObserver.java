
public interface MyObserver {
    void update(double stockPrice);
}
