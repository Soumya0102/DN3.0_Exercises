package builder;

public class BuilderPatternTest {
    public static void main(String[] args) {
        // Creating a basic computer with required parameters
        Computer basicComputer = new Computer.ComputerBuilder("Intel i5", "8GB").build();
        System.out.println(basicComputer);

        // Creating a high-end computer with all parameters
        Computer highEndComputer = new Computer.ComputerBuilder("Intel i9", "32GB")
                .setStorage("1TB SSD")
                .setGraphicsCard("NVIDIA RTX 3080")
                .setOperatingSystem("Windows 11")
                .build();
        System.out.println(highEndComputer);

        // Creating a mid-range computer with some optional parameters
        Computer midRangeComputer = new Computer.ComputerBuilder("AMD Ryzen 5", "16GB")
                .setStorage("512GB SSD")
                .setGraphicsCard("AMD Radeon RX 580")
                .build();
        System.out.println(midRangeComputer);
    }
}

